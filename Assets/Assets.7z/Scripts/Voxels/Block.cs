﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Mathematics;
using System;

public struct Block
{
    public Block(Block T)
    {
        this = T;
    }

    public Block(int ID, bool solid, int2 texture, bool usephysics = false, float physicstime = 0f)
    {
        this.GetID = ID;
        this.Solid_Up = solid;
        this.Solid_Down = solid;
        this.Solid_East = solid;
        this.Solid_West = solid;
        this.Solid_North = solid;
        this.Solid_South = solid;
        this.Texture_Up = texture;
        this.Texture_Down = texture;
        this.Texture_North = texture;
        this.Texture_South = texture;
        this.Texture_East = texture;
        this.Texture_West = texture;
        this.UsePhysics = usephysics;
        this.PhysicsTime = physicstime;
    }

    public Block(int ID, List<bool> solid, List<int2> textures, bool usephysics = false, float physicstime = 0f)
    {
        this.GetID = ID;
        this.Solid_Up = solid[0];
        this.Solid_Down = solid[1];
        this.Solid_East = solid[2];
        this.Solid_West = solid[3];
        this.Solid_North = solid[4];
        this.Solid_South = solid[5];
        this.Texture_Up = textures[0];
        this.Texture_Down = textures[1];
        this.Texture_North = textures[2];
        this.Texture_South = textures[3];
        this.Texture_East = textures[4];
        this.Texture_West = textures[5];
        this.UsePhysics = usephysics;
        this.PhysicsTime = physicstime;
    }

    public Block(int ID, bool solid, List<int2> textures, bool usephysics = false, float physicstime = 0f)
    {
        this.GetID = ID;
        this.Solid_Up = solid;
        this.Solid_Down = solid;
        this.Solid_East = solid;
        this.Solid_West = solid;
        this.Solid_North = solid;
        this.Solid_South = solid;
        this.Texture_Up = textures[0];
        this.Texture_Down = textures[1];
        this.Texture_North = textures[2];
        this.Texture_South = textures[3];
        this.Texture_East = textures[4];
        this.Texture_West = textures[5];
        this.UsePhysics = usephysics;
        this.PhysicsTime = physicstime;
    }

    public Block(int ID)
    {
        this.GetID = ID;
        this.Solid_Up = false;
        this.Solid_Down = false;
        this.Solid_East = false;
        this.Solid_West = false;
        this.Solid_North = false;
        this.Solid_South = false;
        this.Texture_Up = new int2();
        this.Texture_Down = new int2();
        this.Texture_North = new int2();
        this.Texture_South = new int2();
        this.Texture_East = new int2();
        this.Texture_West = new int2();
        this.UsePhysics = false;
        this.PhysicsTime = new float();
    }
    
    public int GetID { get; }

    public bool Solid_Up { get; }
    public bool Solid_Down { get; }
    public bool Solid_North { get; }
    public bool Solid_South { get; }
    public bool Solid_East { get; }
    public bool Solid_West { get; }
    
    public int2 Texture_Up { get; }
    public int2 Texture_Down { get; }
    public int2 Texture_North { get; }
    public int2 Texture_South { get; }
    public int2 Texture_East { get; }
    public int2 Texture_West { get; }

    public bool UsePhysics { get; }

    public float PhysicsTime { get; }
}

public static class BlockData
{
    public static Dictionary<int, Block> sortedByID;
    public static List<Block> byID = new List<Block>();
    public static float BlockTileSize = 0.25f;


    public static void InitalizeBlocks()
    {
        List<bool> Solid = new List<bool>(); // This is for custom blocks
        List<int2> textures;                 // This is for custom blocks
        textures = new List<int2>() {
            new int2(2, 0), // up
            new int2(1, 0), // down
            new int2(3, 0), // north
            new int2(3, 0), // south
            new int2(3, 0), // east
            new int2(3, 0)  // west
        };

        byID.Add(new Block(0));                                   //        AIR
        byID.Add(new Block(1));                                   //        TERRAIN
        byID.Add(new Block(2));                                   //        WATER
        byID.Add(new Block(3));                                   //        Placeholder: LIQUID
        byID.Add(new Block(4));                                   //        Placeholder: LIQUID
        byID.Add(new Block(5));                                   //        Placeholder: LIQUID
        byID.Add(new Block(6));                                   //        Placeholder: LIQUID
        byID.Add(new Block(7));                                   //        Placeholder: LIQUID
        byID.Add(new Block(8));                                   //        Placeholder: LIQUID
        byID.Add(new Block(9));                                   //        Placeholder: LIQUID
        byID.Add(new Block(10));                                  //        Placeholder: LIQUID
        byID.Add(new Block(11, true, new int2(0, 0)));            //        STONE
        byID.Add(new Block(12, true, textures));                  //        GRASS
        byID.Add(new Block(13, true, new int2(1, 0)));            //        GROUND
        byID.Add(new Block(14, true, new int2(0, 0)));            //        COBBLESTONE / LACK OF TEXTURE, TODO
        byID.Add(new Block(15, true, new int2(0, 0)));            //        SAND /        LACK OF TEXTURE, TODO
        byID.Add(new Block(16, true, new int2(0, 0)));            //        GRAVEL /      LACK OF TEXTURE, TODO
        byID.Add(new Block(17, true, new int2(0, 0)));            //        PLANKS /      LACK OF TEXTURE, TODO
        textures = new List<int2>() { new int2(2, 1), new int2(2, 1), new int2(1, 1), new int2(1, 1), new int2(1, 1), new int2(1, 1) };
        byID.Add(new Block(16, true, textures));                  //        WOOD (LOG)
        byID.Add(new Block(16, true, new int2(0, 1)));            //        LEAVES
        byID.Add(new Block(18, true, new int2(0, 0)));            //        GLASS /       LACK OF TEXTURE, TODO
    }
}