﻿using MarchingCubesProject;
using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(MeshCollider))]
public class Chunk : MonoBehaviour
{
    [Header("Base Settings")]
    public World world;
    public WorldPos pos;
    [ReadOnly] public static int chunkSize = 16;
    
    public Block[] blocks = new Block[chunkSize^3];
    public NativeArray<Block> Native_blocks;
    public NativeArray<Block> Native_blocks2;

    [Header("Sub-Chunk prefabs")]
    public GameObject Chunk_Water;
    public GameObject Chunk_Smoothed;

    [Header("Marching Cubes Settings")]
    [Range(0.501f, 1f)]
    public float MarchingCubesSmoothness = 1f;

    [Header("Force Update and Testing")]
    public bool update = false;
    public bool TestMapgen = false;

    [Header("Job System")]
    NativeArray<Block> blocktypes;
    NativeArray<float> _counter;
    private JobHandle MapGen_JobHandle = new JobHandle();
    private JobHandle Render_JobHandle = new JobHandle();
    private bool IsGenerated = false;
    private bool IsRendered = false;
    NativeList<Vector3> verts;
    NativeList<int> tris;
    NativeList<Vector2> uv;
    private bool IsGenerating = false;
    private bool IsRendering = false;


    [Header("Mesh")]
    MeshFilter filter;
    MeshCollider coll;
    
    void Awake()
    {
        filter = gameObject.GetComponent<MeshFilter>();
        coll = gameObject.GetComponent<MeshCollider>();

        blocktypes = new NativeArray<Block>(BlockData.byID.Count, Allocator.Persistent);
        blocktypes.CopyFrom(BlockData.byID.ToArray());
    }
    
    void Update()
    {
        if (update)
        {
            update = false;
            UpdateChunk();
        }
        if (TestMapgen)
        {
            TestMapgen = false;
            GenerateChunk();
        }
    }

    #region "Block Functions"

    public Block GetBlock(int x, int y, int z)
    {
        if (InRange(x) && InRange(y) && InRange(z))
            return blocks[x + y * 16 + z * 256];
        return world.GetBlock(pos.x + x, pos.y + y, pos.z + z);
    }

    public static bool InRange(int index)
    {
        if (index < 0 || index >= chunkSize)
            return false;

        return true;
    }

#pragma warning disable 168
    public void SetBlock(int x, int y, int z, Block block, bool Physics = false)
    {
        try {
            if (blocks[x + y * 16 + z * 256].GetID != 0)
            {
                //blocks[x, y, z].OnDelete(this, x, y, z);
            }
        } catch (Exception e) { }

        if (InRange(x) && InRange(y) && InRange(z))
        {
            blocks[x + y * 16 + z * 256] = block;
        }
        else
        {
            world.SetBlock(pos.x + x, pos.y + y, pos.z + z, block, 0, Physics);
        }

        try
        {
            if (blocks[x + y * 16 + z * 256].GetID != 0 && Physics == true)
            {
                //blocks[x, y, z].OnPlace(this, x, y, z);
            }

        }
        catch (Exception e)
        {
            //Debug.Log ("Can't run OnDelete() on block " + this.GetType ().ToString () + ", at " + x + ", " + y + ", " + z);
        }

    }
#pragma warning restore 168

    public void SetBlockFromGen(int x, int y, int z, Block block, byte modifier = 0)
    {
        if (InRange(x) && InRange(y) && InRange(z))
        {
            blocks[x + y * 16 + z * 256] = block;
        }
        else
        {
            world.SetBlock(pos.x + x, pos.y + y, pos.z + z, block);
        }
    }

    #endregion
    
    #region "Job System - Main stuff"
    void OnDestroy()
    {
        if (Native_blocks.IsCreated) Native_blocks.Dispose();
        if (blocktypes.IsCreated) blocktypes.Dispose();
        if (verts.IsCreated) verts.Dispose();
        if (tris.IsCreated) tris.Dispose();
        if (uv.IsCreated) uv.Dispose();
    }

    void LateUpdate()
    {
        if (IsGenerating)
        {
            IsGenerating = false;
            MapGen_JobHandle.Complete();
            blocks = new Block[Native_blocks.Length];
            Native_blocks.CopyTo(blocks);
            Native_blocks.Dispose();
            world.GeneratedChunks += 1;
        }
        if (IsRendering && Render_JobHandle.IsCompleted)
        {
            IsRendering = false;
            Render_JobHandle.Complete();

            filter.mesh.vertices = verts.ToArray();
            filter.mesh.triangles = tris.ToArray();
            filter.mesh.uv = uv.ToArray();
            filter.mesh.RecalculateNormals();

            coll.sharedMesh = null;

            Mesh mesh = new Mesh();
            mesh.vertices = verts.ToArray();
            mesh.triangles = tris.ToArray();
            mesh.MarkDynamic();
            mesh.RecalculateNormals();

            coll.sharedMesh = mesh;

            verts.Dispose(); tris.Dispose(); uv.Dispose();
        }
    }
    #endregion

    #region "Job System/Unity ECS - Chunk Rendering"

    void UpdateChunk()
    {
        if (Render_JobHandle.IsCompleted && !Native_blocks2.IsCreated)
        {
            NativeArray<Block> Chunk_MinusX = new NativeArray<Block>(4096, Allocator.TempJob);
            if (world.GetChunk((pos.x - 16), pos.y, pos.z) != null)
                Chunk_MinusX.CopyFrom(world.GetChunk((pos.x - 16), pos.y, pos.z).blocks);
            
            NativeArray<Block> Chunk_PlusX = new NativeArray<Block>(4096, Allocator.TempJob);
            if (world.GetChunk((pos.x + 16), pos.y, pos.z) != null)
                Chunk_PlusX.CopyFrom(world.GetChunk((pos.x + 16), pos.y, pos.z).blocks);

            NativeArray<Block> Chunk_MinusY = new NativeArray<Block>(4096, Allocator.TempJob);
            if (world.GetChunk(pos.x, (pos.y - 16), pos.z) != null)
                Chunk_MinusY.CopyFrom(world.GetChunk(pos.x, (pos.y - 16), pos.z).blocks);

            NativeArray<Block> Chunk_PlusY = new NativeArray<Block>(4096, Allocator.TempJob);
            if (world.GetChunk(pos.x, (pos.y + 16), pos.z) != null)
                Chunk_PlusY.CopyFrom(world.GetChunk(pos.x, (pos.y + 16), pos.z).blocks);

            NativeArray<Block> Chunk_MinusZ = new NativeArray<Block>(4096, Allocator.TempJob);
            if (world.GetChunk(pos.x, pos.y, (pos.z - 16)) != null)
                Chunk_MinusZ.CopyFrom(world.GetChunk(pos.x, pos.y, (pos.z - 16)).blocks);

            NativeArray<Block> Chunk_PlusZ = new NativeArray<Block>(4096, Allocator.TempJob);
            if (world.GetChunk(pos.x, pos.y, (pos.z + 16)) != null) 
                Chunk_PlusZ.CopyFrom(world.GetChunk(pos.x, pos.y, (pos.z + 16)).blocks);

            Native_blocks2 = new NativeArray<Block>(4096, Allocator.TempJob);

            Native_blocks2.CopyFrom(blocks);
            verts = new NativeList<Vector3>(Allocator.TempJob);
            tris = new NativeList<int>(Allocator.TempJob);
            uv = new NativeList<Vector2>(Allocator.TempJob);

            NativeArray<bool> GreedyBlocks = new NativeArray<bool>(4096, Allocator.TempJob);


            var job = new Job_RenderChunk()
            {
                tileSize = BlockData.BlockTileSize,
                vertices = verts,
                triangles = tris,
                uvs = uv,
                _blocks = Native_blocks2,
                _blocks_greedy = GreedyBlocks,
                blocktype = blocktypes,
                _blocks_MinusX = Chunk_MinusX,
                _blocks_MinusY = Chunk_MinusY,
                _blocks_MinusZ = Chunk_MinusZ,
                _blocks_PlusX = Chunk_PlusX,
                _blocks_PlusY = Chunk_PlusY,
                _blocks_PlusZ = Chunk_PlusZ,
                UseMarchingCubes = false
            };

            Render_JobHandle = job.Schedule();
            IsRendering = true;
            
        }

    }

    //[BurstCompile]
    private struct Job_RenderChunk : IJob
    {
        public NativeList<Vector3> vertices;
        public NativeList<int> triangles;
        public NativeList<Vector2> uvs;
        
        [ReadOnly] public float tileSize;

        [DeallocateOnJobCompletion][ReadOnly] public NativeArray<Block> _blocks;
        [ReadOnly] public NativeArray<Block> blocktype;

        [DeallocateOnJobCompletion][ReadOnly] public NativeArray<Block> _blocks_PlusX;
        [DeallocateOnJobCompletion][ReadOnly] public NativeArray<Block> _blocks_MinusX;
        [DeallocateOnJobCompletion][ReadOnly] public NativeArray<Block> _blocks_PlusY;
        [DeallocateOnJobCompletion][ReadOnly] public NativeArray<Block> _blocks_MinusY;
        [DeallocateOnJobCompletion][ReadOnly] public NativeArray<Block> _blocks_PlusZ;
        [DeallocateOnJobCompletion][ReadOnly] public NativeArray<Block> _blocks_MinusZ;
        
        [DeallocateOnJobCompletion] public NativeArray<bool> _blocks_greedy;

        // RENDERING OPTIONS
        [ReadOnly] public bool UseMarchingCubes;
        
        public void Execute()
        {
            Block tbmx, tbpx, tbmy, tbpy, tbmz, tbpz, tb;
            //Block g_tbmx, g_tbpx, g_tbmy, g_tbpy, g_tbmz, g_tbpz;
            for (int x = 0; x < 16; x++)
            {
                for (int y = 0; y < 16; y++)
                {
                    for (int z = 0; z < 16; z++)
                    {
                        if (_blocks[x + y * 16 + z * 256].GetID != 0 && !_blocks_greedy[x + y * 16 + z * 256]) { // Skip air and greedy
                            if (_blocks[x + y * 16 + z * 256].GetID == 1) {
                                // TERRAIN ( Marching Cubes )

                            } else if (_blocks[x + y * 16 + z * 256].GetID == 2) {
                                // WATER

                            } else if (_blocks[x + y * 16 + z * 256].GetID > 10) {
                                if (x == 0) tbmx = _blocks_MinusX[15 + y * 16 + z * 256]; else tbmx = _blocks[x-1 + y * 16 + z * 256];
                                if (x == 15) tbpx = _blocks_PlusX[y * 16 + z * 256]; else tbpx = _blocks[x+1 + y * 16 + z * 256];
                                if (y == 0) tbmy = _blocks_MinusY[x + (15 * 16) + z * 256]; else tbmy = _blocks[x + (y - 1) * 16 + z * 256];
                                if (y == 15) tbpy = _blocks_PlusY[x + z * 256]; else tbpy = _blocks[x + (y + 1) * 16 + z * 256];
                                if (z == 0) tbmz = _blocks_MinusZ[x + y * 16 + (15 * 256)]; else tbmz = _blocks[x + y * 16 + (z - 1) * 256];
                                if (z == 15) tbpz = _blocks_PlusZ[x + y * 16]; else tbpz = _blocks[x + y * 16 + (z + 1) * 256];

                                tb = _blocks[x + y * 16 + z * 256];

                                // XZ
                                if (tb.Solid_Up && !tbpy.Solid_Down)
                                {
                                    int max_z = 15; //Maximum value for Z axis iterating
                                    int temp_max_z = 15; //Maximum value for Z axis iterating, temporary, to be moved into max_z when X > startX
                                    int greed_x = x; //storage of maximum vertex's X
                                    bool broken = false;

                                    for (int x_greedy = x; x_greedy < chunkSize; x_greedy++)
                                    {
                                        if (broken) break;
                                        if (x_greedy > x) max_z = temp_max_z;
                                        if (x_greedy > x && _blocks[x_greedy + y * 16 + z * 256].GetID != tb.GetID) break;
                                        if (_blocks_greedy[x_greedy + y * 16 + z * 256]) break;

                                        greed_x = x_greedy;

                                        for (int z_greedy = z; z_greedy <= max_z; z_greedy++)
                                        {
                                            // Macro for the block above
                                            bool PlusYSolidDown;
                                            if (y == 15) PlusYSolidDown = _blocks_PlusY[x_greedy + z_greedy * 256].Solid_Down;
                                                else PlusYSolidDown = _blocks[x_greedy + (y + 1) * 16 + z_greedy * 256].Solid_Down;

                                            // Check: Is already greedy + Start block's ID == block ID + block above is transparent from below
                                            if (!_blocks_greedy[x_greedy + y * 16 + z_greedy * 256] && tb.GetID == _blocks[x_greedy + y * 16 + z_greedy * 256].GetID &&
                                                !PlusYSolidDown) {

                                                //sets the temp_max_z value when x_greedy == startX
                                                if (x_greedy == x) temp_max_z = z_greedy;
                                                //sets the block as greedy, so the next iterations will skip it
                                                _blocks_greedy[x_greedy + y * 16 + z_greedy * 256] = true;

                                            } else {

                                                //checks if iteration of Z is not above max_Z (when x_greedy > startX)
                                                if (z_greedy <= max_z && x_greedy > x)
                                                {
                                                    //if so, iterate through last row and set it back to non-greedy
                                                    for (int z1 = z; z1 < z_greedy; z1++)
                                                    {
                                                        _blocks_greedy[x_greedy + y * 16 + z1 * 256] = false;
                                                    }
                                                    //set the X value for vertex to x_greedy - 1
                                                    greed_x = x_greedy - 1;

                                                    //break entire thing
                                                    broken = true;
                                                    break;

                                                }
                                            }
                                        }
                                    }
                                    //if (max_z < greed_z) greed_z = max_z;

                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, max_z + 0.5f));
                                    vertices.Add(new Vector3(greed_x + 0.5f, y + 0.5f, max_z + 0.5f));
                                    vertices.Add(new Vector3(greed_x + 0.5f, y + 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, z - 0.5f));
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 3);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 1);
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + tileSize - 0.001f, tileSize * tb.Texture_Up.y + 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + tileSize - 0.001f, tileSize * tb.Texture_Up.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + 0.001f, tileSize * tb.Texture_Up.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + 0.001f, tileSize * tb.Texture_Up.y + 0.001f));
                                } else
                                {
                                }

                                /*if (!_blocks_greedy[x + y * 16 + z * 256] && tb.Solid_Up && !tbpy.Solid_Down && ((tbpy.GetID == 0) || ((tbpy.GetID > 1) && (tbpy.GetID < 11))))
                                {
                                    for (int x_greedy = x; x_greedy < chunkSize; x_greedy++)
                                    {
                                        for (int z_greedy = z; z_greedy < chunkSize; z_greedy++)
                                        {
                                            if (_blocks[x_greedy + y * 16 + z_greedy * 256].GetID == tb.GetID && !_blocks_greedy[x_greedy + y * 16 + z_greedy * 256])
                                            {
                                                if (!stop) {
                                                    //if (x_greedy == 0) g_tbmx = _blocks_MinusX[15 + y * 16 + z_greedy * 256]; else g_tbmx = _blocks[x_greedy - 1 + y * 16 + z_greedy * 256];
                                                    //if (x_greedy == 15) g_tbpx = _blocks_PlusX[y * 16 + z_greedy * 256]; else g_tbpx = _blocks[x_greedy + 1 + y * 16 + z_greedy * 256];
                                                    //if (y == 0) g_tbmy = _blocks_MinusY[x_greedy + (15 * 16) + z_greedy * 256]; else g_tbmy = _blocks[x_greedy + (y - 1) * 16 + z_greedy * 256];
                                                    if (y == 15) g_tbpy = _blocks_PlusY[x_greedy + z_greedy * 256]; else g_tbpy = _blocks[x_greedy + (y + 1) * 16 + z_greedy * 256];
                                                    //if (z_greedy == 0) g_tbmz = _blocks_MinusZ[x_greedy + y * 16 + (15 * 256)]; else g_tbmz = _blocks[x_greedy + y * 16 + (z_greedy - 1) * 256];
                                                    //if (z_greedy == 15) g_tbpz = _blocks_PlusZ[x_greedy + y * 16]; else g_tbpz = _blocks[x_greedy + y * 16 + (z_greedy + 1) * 256];

                                                    if (!g_tbpy.Solid_Down && ((g_tbpy.GetID == 0) || ((g_tbpy.GetID > 1) && (g_tbpy.GetID < 11))))
                                                    {
                                                        max_x = x_greedy; max_z = z_greedy;
                                                        _blocks_greedy[x_greedy + y * 16 + z_greedy * 256] = true;
                                                    }
                                                }
                                            } else {
                                                stop = true;
                                            }
                                        }
                                    }
                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, max_z + 0.5f));
                                    vertices.Add(new Vector3(max_x + 0.5f, y + 0.5f, max_z + 0.5f));
                                    vertices.Add(new Vector3(max_x + 0.5f, y + 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, z - 0.5f));
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 3);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 1);
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + tileSize - 0.001f, tileSize * tb.Texture_Up.y + 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + tileSize - 0.001f, tileSize * tb.Texture_Up.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + 0.001f, tileSize * tb.Texture_Up.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + 0.001f, tileSize * tb.Texture_Up.y + 0.001f));
                                }*/
                                /*
                                // XY
                                for (int x_greedy = x; x_greedy < chunkSize; x_greedy++)
                                {
                                    for (int y_greedy = y; y_greedy < chunkSize; y_greedy++)
                                    {
                                        if (_blocks[x_greedy + y_greedy * 16 + z * 256].GetID == tb.GetID)
                                        {

                                        }
                                    }
                                }

                                // YZ
                                for (int y_greedy = y; y_greedy < chunkSize; y_greedy++)
                                {
                                    for (int z_greedy = z; z_greedy < chunkSize; z_greedy++)
                                    {
                                        if (_blocks[x + y_greedy * 16 + z_greedy * 256].GetID == tb.GetID)
                                        {

                                        }
                                    }
                                }
                                

                                if (tb.Solid_Up && !tbpy.Solid_Down && ((tbpy.GetID == 0) || ((tbpy.GetID > 1) && (tbpy.GetID < 11))))
                                {
                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, z + 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y + 0.5f, z + 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y + 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, z - 0.5f));
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 3);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 1);
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + tileSize - 0.001f, tileSize * tb.Texture_Up.y + 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + tileSize - 0.001f, tileSize * tb.Texture_Up.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + 0.001f, tileSize * tb.Texture_Up.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Up.x + 0.001f, tileSize * tb.Texture_Up.y + 0.001f));
                                }
                                */
                                if (tb.Solid_Down && !tbmy.Solid_Up && ((tbmy.GetID == 0) || ((tbmy.GetID > 1) && (tbmy.GetID < 11))))
                                {
                                    vertices.Add(new Vector3(x - 0.5f, y - 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y - 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y - 0.5f, z + 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y - 0.5f, z + 0.5f));
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 3);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 1);
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Down.x + tileSize - 0.001f, tileSize * tb.Texture_Down.y + 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Down.x + tileSize - 0.001f, tileSize * tb.Texture_Down.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Down.x + 0.001f, tileSize * tb.Texture_Down.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_Down.x + 0.001f, tileSize * tb.Texture_Down.y + 0.001f));
                                }

                                if (tb.Solid_North && !tbpz.Solid_South && ((tbpz.GetID == 0) || ((tbpz.GetID > 1) && (tbpz.GetID < 11))))
                                {
                                    vertices.Add(new Vector3(x + 0.5f, y - 0.5f, z + 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y + 0.5f, z + 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, z + 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y - 0.5f, z + 0.5f));
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 3);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 1);
                                    uvs.Add(new Vector2(tileSize * tb.Texture_North.x + tileSize - 0.001f, tileSize * tb.Texture_North.y + 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_North.x + tileSize - 0.001f, tileSize * tb.Texture_North.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_North.x + 0.001f, tileSize * tb.Texture_North.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_North.x + 0.001f, tileSize * tb.Texture_North.y + 0.001f));
                                }

                                if (tb.Solid_South && !tbmz.Solid_North && ((tbmz.GetID == 0) || ((tbmz.GetID > 1) && (tbmz.GetID < 11))))
                                {
                                    vertices.Add(new Vector3(x - 0.5f, y - 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y + 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y - 0.5f, z - 0.5f));
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 3);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 1);
                                    uvs.Add(new Vector2(tileSize * tb.Texture_South.x + tileSize - 0.001f, tileSize * tb.Texture_South.y + 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_South.x + tileSize - 0.001f, tileSize * tb.Texture_South.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_South.x + 0.001f, tileSize * tb.Texture_South.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_South.x + 0.001f, tileSize * tb.Texture_South.y + 0.001f));
                                }

                                if (tb.Solid_East && !tbpx.Solid_West && ((tbpx.GetID == 0) || ((tbpx.GetID > 1) && (tbpx.GetID < 11))))
                                {
                                    vertices.Add(new Vector3(x + 0.5f, y - 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y + 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y + 0.5f, z + 0.5f));
                                    vertices.Add(new Vector3(x + 0.5f, y - 0.5f, z + 0.5f));
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 3);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 1);
                                    uvs.Add(new Vector2(tileSize * tb.Texture_East.x + tileSize - 0.001f, tileSize * tb.Texture_East.y + 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_East.x + tileSize - 0.001f, tileSize * tb.Texture_East.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_East.x + 0.001f, tileSize * tb.Texture_East.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_East.x + 0.001f, tileSize * tb.Texture_East.y + 0.001f));
                                }

                                if (tb.Solid_West && !tbmx.Solid_East && ((tbmx.GetID == 0) || ((tbmx.GetID > 1) && (tbmx.GetID < 11))))
                                {
                                    vertices.Add(new Vector3(x - 0.5f, y - 0.5f, z + 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, z + 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y + 0.5f, z - 0.5f));
                                    vertices.Add(new Vector3(x - 0.5f, y - 0.5f, z - 0.5f));
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 3);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 4);
                                    triangles.Add(vertices.Length - 2);
                                    triangles.Add(vertices.Length - 1);
                                    uvs.Add(new Vector2(tileSize * tb.Texture_West.x + tileSize - 0.001f, tileSize * tb.Texture_West.y + 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_West.x + tileSize - 0.001f, tileSize * tb.Texture_West.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_West.x + 0.001f, tileSize * tb.Texture_West.y + tileSize - 0.001f));
                                    uvs.Add(new Vector2(tileSize * tb.Texture_West.x + 0.001f, tileSize * tb.Texture_West.y + 0.001f));
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    #endregion

    #region "Job System/Unity ECS - Chunk Generation"

    public void GenerateChunk()
    {
        if (MapGen_JobHandle.IsCompleted && !Native_blocks.IsCreated)
        {
            Native_blocks = new NativeArray<Block>(4096, Allocator.TempJob);
            
            _counter = new NativeArray<float>(30, Allocator.TempJob);
            float3 _ChunkCoordinates = new float3(pos.x, pos.y, pos.z);
            float Height_Dunes_ = (16) * 0.52f;
            float Height_Sand_ = (16) * 0.52f;
            float Height_Water_ = (16) * 0.5f;
            float Height_Dirt_ = (16) * 0.3f;
            float Height_Mountain_ = (16) * 0.7f;

            var job = new WorldGen()
            {
                random = new Unity.Mathematics.Random(0x6E624EB7u),
                _blocksNew = Native_blocks,
                Counter = _counter,
                ChunkCoordinates = new Vector3(pos.x, pos.y, pos.z),
                World_Size = new int3(16, 16, 16),
                Height_Dunes = Height_Dunes_,
                Height_Sand = Height_Sand_,
                Height_Water = Height_Water_,
                Height_Dirt = Height_Dirt_,
                Height_Mountain = Height_Mountain_,
                blocktype = blocktypes // BlockData values
            };

            MapGen_JobHandle = job.Schedule();
            IsGenerating = true;
            //MapGen_JobHandle.Complete();
            //blocks = new Block[Native_blocks.Length];
            //Native_blocks.CopyTo(blocks);
            //Native_blocks.Dispose();

            //Debug.Log("Mapgen done. " + this.gameObject.name);
        }
    }

    [BurstCompile]
    private struct WorldGen : IJob
    {
        [DeallocateOnJobCompletion][ReadOnly] public Unity.Mathematics.Random random;

        [DeallocateOnJobCompletion][ReadOnly] public float3 ChunkCoordinates;
        
        [DeallocateOnJobCompletion] public NativeArray<float> Counter;

        [DeallocateOnJobCompletion][ReadOnly] public int3 World_Size;

        [DeallocateOnJobCompletion][ReadOnly] public float Height_Dunes;
        [DeallocateOnJobCompletion][ReadOnly] public float Height_Sand;
        [DeallocateOnJobCompletion][ReadOnly] public float Height_Water;

        [DeallocateOnJobCompletion][ReadOnly] public float Height_Dirt;
        [DeallocateOnJobCompletion][ReadOnly] public float Height_Mountain;

        [ReadOnly] public NativeArray<Block> blocktype;

        public NativeArray<Block> _blocksNew;
        
        public void Execute()
        {
            /*byte iterations = 3;
            int size = 2;

            //_blocks[x + y * 16 + z * 256] = 1;
            if (World_Size.x <= 512 && World_Size.z >= 512)
                iterations = 8;
            else if (World_Size.x <= 256 && World_Size.z >= 256)
                iterations = 7;
            else if (World_Size.x <= 128 && World_Size.z >= 128)
                iterations = 6;
            else if (World_Size.x <= 64 && World_Size.z >= 64)
                iterations = 5;
            else if (World_Size.x <= 32 && World_Size.z >= 32)
                iterations = 4;
            else if (World_Size.x <= 16 && World_Size.z >= 16)
                iterations = 3;
            
            for (int ix = 0; ix <= size; ix++)
            {
                for (int iz = 0; iz <= size; iz++)
                {
                    Counter[ix + iz * 10] = random.NextFloat(Height_Dunes);
                    if (Counter[ix + iz * 10] < Height_Dunes)
                        Counter[ix + iz * 10] = (Counter[ix + iz * 10] + Height_Dunes * 10) / 11;
                    Counter[5] = Height_Dunes;
                    Counter[6] = random.NextFloat(Height_Dunes);
                    Counter[7] = (Counter[ix + iz * 10] * Height_Dunes * 10) / 11;
                }
            }

            float RND_Factor, RND_Factor2;

            for (byte i = 1; i >= iterations; i++)
            {
                if (i >= iterations - 3)
                    RND_Factor = 0f;
                else
                    RND_Factor = 0.010f * (iterations - i);

                for (int ix = size; ix <= 0; ix--)
                {
                    for (int iz = size; iz <= 0; iz--)
                    {
                        Counter[(ix * 2) + (iz * 20)] = Counter[ix + iz * 10];
                    }
                }

                for (int ix = 0; ix >= size - 1; ix++)
                {
                    for (int iz = 0; iz >= size - 1; iz++)
                    {
                        if (Counter[(ix * 2) + (iz * 10) * 2] <= Height_Water)
                            RND_Factor2 = RND_Factor * 0.5f;
                        else if (Counter[(ix * 2) + (iz * 10) * 2] <= Height_Sand)
                            RND_Factor2 = RND_Factor * 0.4f;
                        else if (Counter[(ix * 2) + (iz * 10) * 2] <= Height_Mountain)
                            RND_Factor2 = RND_Factor * 1.2f;
                        else
                            RND_Factor2 = RND_Factor;

                        Counter[(ix * 2) + (iz * 20) + 10] = Counter[(ix * 2) + (iz * 20)] + Counter[(ix * 2) + (iz * 20) + 20] / 2 + (random.NextInt(255)-128) * RND_Factor2;
                        Counter[(ix * 2) + (iz * 20) + 12] = Counter[(ix * 2) + (iz * 20)] + Counter[(ix * 2) + (iz * 20) + 22] / 2 + (random.NextInt(255) - 128) * RND_Factor2;

                        Counter[(ix * 2) + (iz * 20) + 1] = Counter[(ix * 2) + (iz * 20)] + Counter[(ix * 2) + (iz * 20) + 2] / 2 + (random.NextInt(255) - 128) * RND_Factor2;
                        Counter[(ix * 2) + (iz * 20) + 21] = Counter[(ix * 2) + (iz * 20) + 20] + Counter[(ix * 2) + (iz * 20) + 22] / 2 + (random.NextInt(255) - 128) * RND_Factor2;

                        Counter[(ix * 2) + (iz * 20) + 11] = Counter[(ix * 2) + (iz * 20)] + Counter[(ix * 2) + (iz * 20) + 2] + Counter[(ix * 2) + (iz * 20) + 20] + Counter[(ix * 2) + (iz * 20) + 22] / 4 + (random.NextInt(255) - 128) * RND_Factor2;
                    }
                }
                size = size * 2;
            }

            for (int ix = 0; ix <= size; ix++)
            {
                for (int iz = 0; iz <= size; iz++)
                {
                    float Height = math.ceil(Counter[ix + (iz * 10)]);
                    if (Height > Height_Water)
                    {
                        for (int iy = 0; iy <= Height; iy++)
                        {
                            if (iy > Height - 5)
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[12];
                            else if (iy > Height_Dirt)
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[13];
                            else
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[11];
                        }
                    }
                    else
                    {
                        for (int iy = 0; iy <= Height_Water; iy++)
                        {
                            if (iy > Height)
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[3];
                            else if (iy == Height_Water)
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[15]; //place palm here (12)
                            else if (iy > Height_Dirt)
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[13];
                            else
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[11];
                        }
                    }
                }
            }

            for (int ix = 0; ix <= size; ix++)
            {
                for (int iz = 0; iz <= size; iz++)
                {
                    float Height = math.ceil(Counter[ix + (iz * 10)]);
                    if (Height > Height_Dunes)
                    {
                        for (int iy = 3; iy <= Height; iy++)
                        {
                            if (iy > Height - 6)
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[11];
                            else if (iy > Height_Sand)
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[12];
                            else
                                _blocksNew[ix + iy * 16 + iz * 256] = blocktype[11];
                        }
                    }
                }
            }*/

            //ChunkCoordinates
            for (int x = 0; x < 16; x++)
            {
                for (int y = 0; y < 16; y++)
                {
                    for (int z = 0; z < 16; z++)
                    {
                        int test = random.NextInt(-1, 1);
                        if (ChunkCoordinates.y + y == 25 + test) {
                            _blocksNew[x + y * 16 + z * 256] = blocktype[12];
                        }
                        else if (ChunkCoordinates.y + y < 25 + test) {
                            _blocksNew[x + y * 16 + z * 256] = blocktype[13];
                        }
                    }
                }
            }
        }
    }

    #endregion

    #region "Junk, old stuff and temporary shit, to be edited/removed"
    // Updates the chunk based on its contents
    /*void UpdateChunk(bool RenderNonSmooth = true, bool RenderSmooth = true, bool RenderWater = true)
    {
        filter.mesh.Clear();

        rendered = true;

        Marching marching = new MarchingCubes();

        float[] voxels = new float[(chunkSize + 1) * (chunkSize + 1) * (chunkSize + 1)];
        float[] voxels_w = new float[(chunkSize + 1) * (chunkSize + 1) * (chunkSize + 1)];
        bool updatewater = false;

        for (int x = 0; x < chunkSize + 1; x++)
        {
            for (int y = 0; y < chunkSize + 1; y++)
            {
                for (int z = 0; z < chunkSize + 1; z++)
                {

                    int idx = x + y * (chunkSize + 1) + z * (chunkSize + 1) * (chunkSize + 1);

                    if ((GetBlock(x, y, z).GetType().ToString() != "BlockAir") &&
                        (GetBlock(x, y, z).GetType().ToString() != "BlockWater"))
                    {
                        if ((GetBlock(x, y, z).GetType().ToString() == "Block") ||
                        (GetBlock(x, y, z).GetType().ToString() == "BlockDirt") ||
                        (GetBlock(x, y, z).GetType().ToString() == "BlockGrass"))
                        {
                            if ((GetBlock(x + 1, y, z).GetType().ToString() == "BlockWater") ||
                                (GetBlock(x + 2, y, z).GetType().ToString() == "BlockWater") ||
                                (GetBlock(x - 1, y, z).GetType().ToString() == "BlockWater") ||
                                (GetBlock(x - 2, y, z).GetType().ToString() == "BlockWater") ||
                                (GetBlock(x, y, z + 1).GetType().ToString() == "BlockWater") ||
                                (GetBlock(x, y, z + 2).GetType().ToString() == "BlockWater") ||
                                (GetBlock(x, y, z - 1).GetType().ToString() == "BlockWater") ||
                                (GetBlock(x, y, z - 2).GetType().ToString() == "BlockWater"))
                            {
                                voxels_w[idx] = 1f;
                            }
                            else
                            {
                                voxels_w[idx] = 0f;
                            }
                            voxels[idx] = MarchingCubesSmoothness;
                        }
                    }
                    else
                    {
                        if (GetBlock(x, y, z).GetType().ToString() == "BlockWater")
                        {
                            voxels_w[idx] = MarchingCubesSmoothness;
                        }
                        voxels[idx] = 0f;
                    }
                }
            }
        }

        List<Vector3> verts = new List<Vector3>();
        List<int> indices = new List<int>();
        marching.Generate(voxels, (chunkSize + 1), (chunkSize + 1), (chunkSize + 1), verts, indices);

        if (updatewater)
        {
            List<Vector3> verts_w = new List<Vector3>();
            List<int> indices_w = new List<int>();
            marching.Generate(voxels_w, (chunkSize + 1), (chunkSize + 1), (chunkSize + 1), verts_w, indices_w);
            MeshFilter filter_w = Chunk_Water.GetComponent<MeshFilter>();
            MeshCollider coll_w = Chunk_Water.GetComponent<MeshCollider>();
            filter_w.mesh.Clear();

            filter_w.mesh.vertices = verts_w.ToArray();
            filter_w.mesh.triangles = indices_w.ToArray();
            filter_w.mesh.RecalculateNormals();

            coll_w.sharedMesh = null;
            Mesh mesh_w = new Mesh();
            mesh_w.vertices = verts_w.ToArray();
            mesh_w.triangles = indices_w.ToArray();
            mesh_w.MarkDynamic();
            mesh_w.RecalculateNormals();

            coll_w.sharedMesh = mesh_w;
        }

        MeshFilter filter_s = Chunk_Smoothed.GetComponent<MeshFilter>();
        MeshCollider coll_s = Chunk_Smoothed.GetComponent<MeshCollider>();
        filter_s.mesh.Clear();

        filter_s.mesh.vertices = verts.ToArray();
        filter_s.mesh.triangles = indices.ToArray();
        filter_s.mesh.MarkDynamic();
        filter_s.mesh.RecalculateBounds();
        filter_s.mesh.RecalculateNormals();

        coll_s.sharedMesh = null;

        Mesh mesh_s = new Mesh();
        mesh_s.vertices = verts.ToArray();
        mesh_s.triangles = indices.ToArray();
        mesh_s.MarkDynamic();
        mesh_s.RecalculateNormals();

        coll_s.sharedMesh = mesh_s;

        MeshData meshData_Main = new MeshData();
        MeshData meshData_Water = new MeshData();

        for (int x = 0; x < chunkSize; x++)
        {
            for (int y = 0; y < chunkSize; y++)
            {
                for (int z = 0; z < chunkSize; z++)
                {
                    if (blocks[x, y, z].GetType().ToString() == "BlockWater")
                    {
                        meshData_Water = blocks[x, y, z].Blockdata(this, x, y, z, meshData_Water);
                        RenderWater = true;
                    }
                    else
                    {
                        if ((GetBlock(x, y, z).GetType().ToString() != "Block") &&
                            (GetBlock(x, y, z).GetType().ToString() != "BlockDirt") &&
                            (GetBlock(x, y, z).GetType().ToString() != "BlockGrass"))
                            meshData_Main = blocks[x, y, z].Blockdata(this, x, y, z, meshData_Main);
                    }
                }
            }
        }

        RenderMesh(meshData_Main);
        if (RenderWater) RenderMeshWater(meshData_Water);
    }

    // Sends the calculated mesh information
    // to the mesh and collision components
    void RenderMesh(MeshData meshData)
    {
        filter.mesh.vertices = meshData.vertices.ToArray();
        filter.mesh.triangles = meshData.triangles.ToArray();
        filter.mesh.uv = meshData.uv.ToArray();
        filter.mesh.RecalculateNormals();

        coll.sharedMesh = null;

        Mesh mesh = new Mesh();
        mesh.vertices = meshData.colVertices.ToArray();
        mesh.triangles = meshData.colTriangles.ToArray();
        mesh.MarkDynamic();
        mesh.RecalculateNormals();

        coll.sharedMesh = mesh;
    }

    void RenderMeshWater(MeshData meshData)
    {
        MeshFilter filter_w = Chunk_Water.GetComponent<MeshFilter>();
        MeshCollider coll_w = Chunk_Water.GetComponent<MeshCollider>();
        filter_w.mesh.Clear();

        filter_w.mesh.vertices = meshData.vertices.ToArray();
        filter_w.mesh.triangles = meshData.triangles.ToArray();
        filter_w.mesh.uv = meshData.uv.ToArray();
        filter_w.mesh.RecalculateNormals();

        coll_w.sharedMesh = null;
        Mesh mesh_w = new Mesh();
        mesh_w.vertices = meshData.colVertices.ToArray();
        mesh_w.triangles = meshData.colTriangles.ToArray();
        mesh_w.MarkDynamic();
        mesh_w.RecalculateNormals();

        coll_w.sharedMesh = mesh_w;
    }*/
                #endregion
            }
