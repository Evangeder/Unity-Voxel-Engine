﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Blocks : ushort
{
    Air = 0,
    Ground = 1,
    Stone = 2,
}